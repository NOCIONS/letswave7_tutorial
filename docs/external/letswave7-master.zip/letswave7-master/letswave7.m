function letswave7
LW_manager;
end