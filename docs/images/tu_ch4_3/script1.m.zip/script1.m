LW_init();
FLW_import_data.get_lwdata('filename','sub093.eeg','is_save',1);

