clc;clear;close all;
LW_init();

%% Step 0. Data Import
lwdata=FLW_import_data.get_lwdata('filename','sub093.eeg','is_save',1);

%% Step 1. Remove Channel IO
option=struct('type','channel','items',{{'Fp1','Fp2','F3','F4','C3','C4','P3','P4','O1','O2','F7','F8','T7','T8','P7','P8','Fz','Cz','Pz','FC1','FC2','CP1','CP2','FC5','FC6','CP5','CP6','FT9','FT10','TP9','TP10','F1','F2','C1','C2','P1','P2','AF3','AF4','FC3','FC4','CP3','CP4','PO3','PO4','F5','F6','C5','C6','P5','P6','AF7','AF8','FT7','FT8','TP7','TP8','PO7','PO8','Fpz','CPz','POz','Oz'}},'suffix','','is_save',0);
lwdata= FLW_selection.get_lwdata(lwdata,option);

%% Step 2. Frequency filtering
option=struct('filter_type','bandpass','high_cutoff',30,'low_cutoff',0.05,'filter_order',4,'suffix','','is_save',0);
lwdata= FLW_butterworth_filter.get_lwdata(lwdata,option);

%% Step 3. Bad electrodes interpolation
option=struct('channel_to_interpolate','P1','channels_for_interpolation_list',{{'Pz','P3','CP1'}},'suffix','','is_save',0);
lwdata= FLW_interpolate_channel.get_lwdata(lwdata,option);

%% Step 4. Compute ICA Matrix
option=struct('ICA_mode',2,'algorithm',1,'num_ICs',40,'suffix','ica','is_save',0);
lwdata= FLW_compute_ICA.get_lwdata(lwdata,option);

%% Step 5. Identify Artifact Component
option=struct('suffix','sp_filter','is_save',0);
lwdataset(1).header=lwdata.header;
lwdataset(1).data=lwdata.data;
lwdataset= FLW_spatial_filter_apply.get_lwdataset(lwdataset,option);
lwdata.header=lwdataset(1).header;
lwdata.data=lwdataset(1).data;
clear lwdataset;

%% Step 6. Segmentation/Epoching
option=struct('event_labels',{{'S  9','S 10'}},'x_start',-1,'x_end',2,'x_duration',3,'suffix','ep','is_save',0);
lwdataset= FLW_segmentation_separate.get_lwdataset(lwdata,option);

for k=1:2
    lwdata.header=lwdataset(k).header;
    lwdata.data=lwdataset(k).data;
    %% Step 7. Reference 
    option=struct('reference_list',{{'TP9','TP10'}},'apply_list',{{'Fp1','Fp2','F3','F4','C3','C4','P3','P4','O1','O2','F7','F8','T7','T8','P7','P8','Fz','Cz','Pz','FC1','FC2','CP1','CP2','FC5','FC6','CP5','CP6','FT9','FT10','TP9','TP10','F1','F2','C1','C2','P1','P2','AF3','AF4','FC3','FC4','CP3','CP4','PO3','PO4','F5','F6','C5','C6','P5','P6','AF7','AF8','FT7','FT8','TP7','TP8','PO7','PO8','Fpz','CPz','POz','Oz'}},'suffix','','is_save',0);
    lwdata= FLW_rereference.get_lwdata(lwdata,option);
    
    %% Step 8. Baseline Correction 
    option=struct('operation','substract','xstart',-1,'xend',0,'suffix','','is_save',0);
    lwdata1= FLW_baseline.get_lwdata(lwdata,option);
    
    %% Step 9. Averaging
    option=struct('operation','average','suffix','','is_save',0);
    lwdata= FLW_average_epochs.get_lwdata(lwdata1,option);
    if k==1
        lwdata.header.name='Sub093 P300 target';
    else
        lwdata.header.name='Sub093 P300 nontarget';
    end
    CLW_save(lwdata);
    
    %% Step 10. CWT and Averaging
    option=struct('wavelet_name','cmor1-1.5','low_frequency',1,'high_frequency',30,'num_frequency_lines',100,'output','amplitude','show_progress',1,'suffix','','is_save',0);
    lwdata= FLW_averaged_CWT.get_lwdata(lwdata1,option);
    
    %% Step 11. Baseline Correction
    option=struct('operation','substract','xstart',-0.75,'xend',-0.25,'suffix','','is_save',0);
    lwdata= FLW_baseline.get_lwdata(lwdata,option);
    if k==1
        lwdata.header.name='cwt Sub093 P300 target';
    else
        lwdata.header.name='cwt Sub093 P300 nontarget';
    end
    CLW_save(lwdata);
end


