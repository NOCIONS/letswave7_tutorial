clc;clear;
LW_init();
%% for the condition of target and nontarget
for condition=1:2
    %% edit the filename for datasets loading
    filename=cell(1,92);
    for sub=1:92
        if condition==1
            filename(sub)={['Sub',num2str(sub,'%03d'),' P300 target.lw6']};
        else
            filename(sub)={['Sub',num2str(sub,'%03d'),' P300 nontarget.lw6']};
        end
    end
    
    %% loading datasets
    option=struct('filename',{filename});
    lwdataset= FLW_load.get_lwdataset(option);
    
    %% merge datasets
    option=struct('type','epoch','suffix','merge_epoch','is_save',1);
    lwdata= FLW_merge.get_lwdata(lwdataset,option);
    
    %% grand average
    option=struct('operation','average','suffix','avg','is_save',1);
    lwdata= FLW_average_epochs.get_lwdata(lwdata,option);
end

%% Statistical Analysis
option=struct('filename',{{'merge_epoch Sub001 P300 target.lw6','merge_epoch Sub001 P300 nontarget.lw6'}});
lwdataset= FLW_load.get_lwdataset(option);
option=struct('test_type','paired sample','tails','both','ref_dataset',1,'alpha',0.05,'permutation',1,'cluster_threshold',0.05,'num_permutations',20000,'show_progress',1,'multiple_sensor',1,'chan_dist',0.16,'suffix','ttest','is_save',1);
lwdataset= FLW_ttest.get_lwdataset(lwdataset,option);






